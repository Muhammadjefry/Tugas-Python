    
    # operator_label = customtkinter.CTkLabel(new_window, font=font3,  text="Operator :", text_color="#fff")
    # operator_label.place(x=20, y=50)
    # operator_entry = customtkinter.CTkEntry(new_window, font=font3, text_color='#000', fg_color="#fff", border_color="#0C9295", border_width=2, width=275)
    # operator_entry.place(x=150, y=50)